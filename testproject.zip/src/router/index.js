//引入路由模块
import VueRouter from "vue-router";
//引入Vue模块
import Vue from "vue";
import store from '../store'
// 把路由模块挂给Vue
Vue.use(VueRouter);

var routes = [
    {
        name: "",
        path: "/",
        component: () => import("../views/LoginView.vue")
    },
    {
        name: "login",
        path: "/login",
        component: () => import("../views/LoginView.vue")
    },
    {
        name: "admin",
        path: "/admin",
        component: () => import("@/views/AdminView.vue")
    },
    // {
    //     name:"card",
    //     path:"/card",
    //     component:()=>import("../views/CardView.vue")
    // },
    // {
    //     name:"department",
    //     path:"/department",
    //     component:()=>import("../views/DepartmentView.vue")
    // },
    {
        name: "main",
        path: "/main",
        component: () => import("../views/MainView.vue"),
        children: [
            {
                name: "cardsearch",
                path: "/cardsearch",
                component: () => import("../views/CardSearchView.vue")
            },
            {
                name: "department",
                path: "/department",
                component: () => import("../views/DepartmentView.vue")
            },
            {
                name: "staff",
                path: "/staff",
                component: () => import("../views/StaffView.vue")
            },
            {
                name: "role",
                path: "/role",
                component: () => import("../views/RoleView.vue")
            },
            {
                name: "menu",
                path: "/menu",
                component: () => import("../views/MenuView.vue")
            }
        ]
    }
];

var router = new VueRouter({
    mode: "hash",
    routes
})

//全局路由守卫-->>拦截所有守卫
router.beforeEach((to, from, next) => {
    //废弃从本地存储获取
    // var userIndex = sessionStorage.getItem("user")

    var userIndex = store.state.admin
    var whiteList = ["/login", '/']
    var index = whiteList.indexOf(to.path)

    if (index == -1) {
        if (!userIndex.adminName) {
            alert("请先登录")
            if (from.path != to.path) {
                router.push({
                    path: "/login?redirect=" + to.path
                })
            }
        } else {
            next()
        }
    } else {
        next()
    }



})

export default router