import Vue from 'vue'
import Vuex from "vuex";

Vue.use(Vuex);

var store = new Vuex.Store({//开启状态管理器
    state:{
        siteTitle:"一卡通管理后台",//站点名称
        admin:{},
    },
    getters:{
        getSiteTitle(state){
            return state.siteTitle
        },
        getAdmin(state){
            return state.admin
        }
    },
    mutations:{
        setSiteTitle(state,newTitle){
            state.siteTitle = newTitle;
        },
        setAdmin(state,newAdmin){
            state.admin = newAdmin;
        }
    },
    actions:{
        setAdmin(store,newAdmin){
            store.commit('setAdmin',newAdmin);
        }
    }
})


export default store;