//将t1暴露出去，让外面能够使用
function t1(){
    alert(1)
}

export default{
    t1
}