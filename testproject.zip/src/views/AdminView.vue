<template>
    <div>
        这是管理员列表组件{{ msg }}
    </div>
</template>

<script>
    export default{
        data(){
            return{
                msg:"hello,world"
            }
        }
    }
</script>

<style>
    
</style>