<template>
    <div>
        <el-table :data="tableData" style="width: 100%">
            <el-table-column prop="cardId" label="id" width="180">
            </el-table-column>
            <el-table-column prop="cardNumber" label="卡号" width="180">
            </el-table-column>
            <el-table-column prop="cardMoney" label="余额">
            </el-table-column>
            <el-table-column prop="cardStatus" label="卡状态">
            </el-table-column>
            <el-table-column label="操作">
                <el-button>编辑</el-button>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination layout="prev, pager, next" :total=total :page-size="pageSize"
                @current-change="handleCurrentChange" :current-page="currentPage">
            </el-pagination>
        </div>

    </div>
</template>

<script>
// import axios from 'axios';

export default {
    data() {
        return {
            tableData: [],
            total: 0,
            pageSize: 7,
            currentPage: 1,
        }
    },
    mounted() {
        this.getAdmin();
    },
    methods: {
        getAdmin() {
            this.$axios.post(
                "/card/getAllCardByPage",
                {
                    pagen: this.currentPage,
                    limit: this.pageSize
                }
            ).then((res) => {
                this.tableData = res.data.list
                this.pageSize = res.data.pageSize
                this.total = res.data.total
                console.log(res.data);
            })
        },
        handleCurrentChange(index) {
            this.currentPage = index
            this.getAdmin()
        }
    }
}

</script>

<style scoped>
.el-table {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 20px;
}

.block {
    line-height: 30px;
}
</style>