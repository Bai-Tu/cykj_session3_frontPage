<template>
    <div>
        这是科室列表组件{{ msg }}
        {{ admin }}
    </div>
</template>

<script>
    export default{
        data(){
            return{
                msg:"hello,world",
                admin:this.$store.state.admin
            }
        },
        mounted(){
            var newAdmin = {
                name:"zhangsan",
                budget:123.1
            }
            this.$store.dispatch('setAdmin',newAdmin);
            console.log(this.$store.state.admin);
        }
    }
</script>

<style>
    
</style>