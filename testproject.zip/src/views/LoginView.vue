<template>
    <div class="content" id="mainContent">
        <div class="login-box">
            <h1>SIGN IN</h1>
            <div class="output-frame">
                <label for="username">账号</label>
                <input type="text" id="account" autofocus v-model="acc">
            </div>
            <div class="output-frame">
                <label for="password">密码</label>
                <input type="password" id="password" v-model="pwd">
            </div>
            <div class="output-frame" id="check_1">
                <label for="checkCode" id="check_2">验证</label>
                <input type="text" id="inputCode" v-model="inputCode">
                <div @click="refreshCode">
                    <img :src="imgUrl" style="position: absolute; width: 120px;height:40px ;">
                </div>
            </div>
            <button class="login-btn" id="button_login" @click="doLogin">登录</button>
        </div>
    </div>
</template>

<script>
// import axios from 'axios';

export default {
    data() {
        return {
            acc: "admin",
            pwd: "123456",
            data: [],
            checkCode: '',
            imgUrl: '',
            inputCode: ''
        }
    },
    mounted() {
        this.refreshCode()
    },
    methods: {
        doLogin() {
            if (this.inputCode == this.checkCode) {
                this.$axios.post(
                    "/admin/loginAdmin",
                    {
                        adminAccount: this.acc,
                        adminPwd: this.pwd
                    }
                ).then((res) => {
                    console.log(res);
                    this.data = res.data;
                    if (res.code == 1) {
                        this.$store.commit('setAdmin', this.data)
                        sessionStorage.setItem("user", JSON.stringify(this.data));
                        alert("success")
                        if (location.href.includes('?redirect')) {
                            var urlobj = location.href.split('redirect=')[1];
                            var newDes = decodeURIComponent(urlobj);
                            this.$router.push({
                                path: newDes
                            })
                        } else {
                            this.$router.push({
                                path: "/main"
                            })
                        }

                    } else {
                        alert("fail")
                    }
                })
            }else{
                this.inputCode = ''
                alert("验证码错误");
                this.refreshCode()
            }
        },
        refreshCode() {
            this.$axios.post(
                "/admin/refreshCheckCode"
            ).then((res) => {
                this.imgUrl = "data:image/png;base64," + res.data.img
                this.checkCode = res.data.code;
                console.log(res);
            })
        }
    }

}
</script>

<style scoped>
* {
    margin: 0;
    padding: 0;
}

.content {
    position: relative;
    width: 100vw;
    height: 100vh;
    background-color: antiquewhite;

    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
}

.content::before {
    position: absolute;
    content: "";
    display: block;
    width: 300%;
    height: 100%;
    background-image: linear-gradient(to bottom right,
            rgb(25, 0, 255), rgb(111, 0, 255), rgb(242, 0, 250));
    filter: blur(4px);
    animation: bg-anim 10s alternate infinite linear;
}

@keyframes bg-anim {
    from {
        left: 0;
    }

    to {
        left: -200%;
    }
}

.login-box {
    position: relative;
    width: 400px;
    height: 450px;
    background-color: rgba(74, 0, 170, 0.3);
    border-radius: 30px;
    color: #fff;

    display: flex;
    flex-direction: column;
    align-items: center;
}

.login-box>h1 {
    margin: 50px 0 10px 0;
    font-size: 64px;
}

.output-frame {
    margin-top: 20px;
    width: 300px;
    height: 40px;

    display: flex;
}


.output-frame>label {
    font-size: 16px;
    width: 64px;
    background-color: rgba(212, 0, 219, 0.6);
    border-radius: 40px 10px 10px 40px;
    text-indent: 20px;

    display: flex;
    align-items: center;
}

.output-frame>input {
    flex: 1;
    width: 0;
    margin-left: 6px;
    padding: 0 20px 0 10px;
    border-radius: 10px 40px 40px 10px;
    outline: none;
    border: none;
    font-size: 20px;
    background-color: rgba(74, 0, 170, 0.3);
    color: #fff;
}

.output-frame>input:focus {
    color: #000;
    background-color: #fff;
}

#check_1 {
    width: 200px;
    margin-left: -100px;
}


#codeImg {
    position: absolute;
    width: 60px;
    height: 30px;
    right: 80px;
    font-size: 20px;
}

.login-btn {
    margin-top: 40px;
    width: 200px;
    height: 40px;
    font-size: 20px;
    border: none;
    background-color: rgba(212, 0, 219, 0.6);
    color: #fff;
    border-radius: 40px;
}

.login-btn:hover {
    background-color: rgba(212, 0, 219, 0.8);
}
</style>