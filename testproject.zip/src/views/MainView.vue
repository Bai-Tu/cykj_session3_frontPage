<template>
    <div>
        <el-container style="height: 100vh;">
            <el-aside width="200px">
                <p style="width: 200px;height: 60px; font-size: 20px; 
                position: relative; bottom: 70px;  text-align: center; right: 10px;"
                >{{ this.$store.getters.getSiteTitle }}</p>
                <!-- <el-tree :data="data.menuList" :props="defaultProps" @node-click="handleNodeClick"></el-tree> -->
                <el-row class="tac">
                    <el-col :span="24">
                        <el-menu v-for="(item, index) in menuList" :key="item.menuId" :default-active="$route.path"
                            class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose"
                            @select="handleSeclect" background-color="#545c64" text-color="#fff"
                            active-text-color="#ffd04b" :router="true" :unique-opened="true">

                            <el-submenu v-if="item.children.length > 0" :index="index + ''">
                                <template slot="title">
                                    <i :class="item.menuIcon" v-if="item.menuIcon !== ''"></i>
                                    <i class="el-icon-menu" v-else></i>
                                    <span>{{ item.menuName }}</span>
                                </template>
                                <el-menu-item v-for="(subItem) in item.children" :key="subItem.menuId"
                                    :index="subItem.menuPath">
                                    {{ subItem.menuName }}
                                </el-menu-item>
                            </el-submenu>

                            <el-menu-item v-else :index="item.menuPath">
                                <i :class="item.menuIcon" v-if="item.menuIcon !== ''"></i>
                                <i class="el-icon-menu" v-else></i>
                                <span slot="title">{{ item.menuName }}</span>
                            </el-menu-item>
                        </el-menu>
                    </el-col>
                </el-row>
            </el-aside>

            <el-container>
                <el-header style="text-align: right; font-size: 12px">
                    <el-dropdown>
                        <i class="el-icon-setting" style="margin-right: 15px;cursor:default;">
                            <el-dropdown-menu slot="dropdown">
                                <el-dropdown-item>个人信息</el-dropdown-item>
                                <el-dropdown-item>修改密码</el-dropdown-item>
                                <el-dropdown-item>退出登录</el-dropdown-item>
                            </el-dropdown-menu>
                            <span>{{ name }}</span>
                        </i>
                    </el-dropdown>
                </el-header>

                <el-main>
                    <router-view></router-view>
                </el-main>

                <el-footer>Footer</el-footer>
            </el-container>
        </el-container>
    </div>
</template>

<script>

// import router from '@/router';

export default {
    data() {
        return {
            menuList: [],
            name: '狗管理',
            roleId: 1
        }
    },
    created() {
        this.changeIndex();
        this.getMenu()
        // this.$store.commit('setSiteTitle','后台')
        console.log('im admin',this.$store.state.admin);
    },
    methods: {
        handleOpen(key, keyPath) {
            console.log(key, keyPath);
        },
        handleClose(key, keyPath) {
            console.log(key, keyPath);
        },
        handleSeclect(index, indexPath) {
            console.log(index, indexPath);
        },
        changeIndex() {
            const userIndex = JSON.parse(sessionStorage.getItem("user"));
            this.name = userIndex.adminName;
            this.roleId = userIndex.adminId;
        },
        getMenu() {
            this.$axios.post(
                "/menu/searchMenuByRoleInTree",
                {
                    roleId: this.roleId,
                }
            ).then((res) => {
                console.log(res);
                this.menuList = res.data
            })
        }
    }
}




</script>

<style scoped>
.el-header,
.el-footer {
    background-color: #B3C0D1;
    color: #333;
    text-align: center;
    line-height: 60px;
}

.el-aside {
    background-color: #D3DCE6;
    color: #333;
    text-align: left;
    line-height: 200px;
    height: 100vh;
}

.el-main {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
}

body>.el-container {
    margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
    line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
    line-height: 320px;
}
</style>