<template>
    <div>
        <el-table :data="tableData" style="width: 100%">
            <el-table-column prop="roleId" label="id" width="200">
            </el-table-column>
            <el-table-column prop="roleName" label="名字" width="300">
            </el-table-column>
            <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button @click="openForm(scope.row)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination layout="prev, pager, next" :total=total :page-size="pageSize"
                @current-change="handleCurrentChange" :current-page="currentPage">
            </el-pagination>
        </div>

        <!-- Form -->
        <el-dialog title="权限管理" :visible.sync="dialogFormVisible" width="50%">
            <!-- <el-transfer v-model="value" :data="data" style="text-align: left;"></el-transfer> -->
            <tree-transfer :from_data="leftData" :to_data="rightData" mode="transfer" height='320px' openAll ></tree-transfer>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="submitContent">确 定</el-button>
            </div>
        </el-dialog>

    </div>
</template>

<script>
// import axios from 'axios';
import treeTransfer from 'el-tree-transfer';

export default {
    data() {
        const generateData = () => {
            const data = [];
            for (let i = 1; i <= 15; i++) {
                data.push({
                    key: i,
                    label: `备选项 ${i}`,
                    disabled: i % 4 === 0
                });
            }
            return data;
        };
        return {
            tableData:[],
            leftData: [],
            rightData:[],
            total: 0,
            pageSize: 5,
            currentPage: 1,
            dialogFormVisible: false,
            formLabelWidth: '120px',
            data: generateData(),
            value: [1, 4],
            selectedRow: {}
        }
    },
    mounted() {
        this.getRole();
    },
    methods: {
        getRole() {
            this.$axios.post(
                "/role/getAllRole",
            ).then((res) => {
                this.tableData = res.data
                console.log(res.data);
            })
        },
        handleCurrentChange(index) {
            this.currentPage = index
            this.getAdmin()
        },
        openForm(row) {
            this.getAdminMenu(row.roleId);
            this.dialogFormVisible = true
            console.log(row);
            this.$axios.post(
                "/menu/getDifferentTree",
                {
                    roleId:row.roleId
                }
            ).then((res)=>{
                    this.leftData = res.data
                })
        },
        getAdminMenu(roleId){
            this.$axios.post(
                "/menu/searchMenuByRoleInEletree",
                {
                    roleId
                }
            ).then((res)=>{
                this.selectedRow = res.data
                this.rightData = res.data
            })
        },
        submitContent(){
            this.dialogFormVisible = false
        }
    },
    components:{
        treeTransfer
    }
}

</script>

<style scoped>
.el-table {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 20px;
}

.el-transfer-panel__item .el-checkbox__inputt{
    position: absolute;
    top: 8px;
    left: 20px !important; 
}
</style>

<style>
.transfer-title{
    margin-top:0; 
}
</style>