<template>
    <div>
        <el-table :data="tableData" style="width: 100%">
            <el-table-column prop="adminId" label="id" width="180">
            </el-table-column>
            <el-table-column prop="adminAccount" label="账号" width="180">
            </el-table-column>
            <el-table-column prop="adminPwd" label="密码">
            </el-table-column>
            <el-table-column prop="adminName" label="昵称">
            </el-table-column>
            <el-table-column label="操作">
                <template slot-scope="scope">
                    <el-button @click="openForm(scope.row)">编辑</el-button>
                </template>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination layout="prev, pager, next" :total=total :page-size="pageSize"
                @current-change="handleCurrentChange" :current-page="currentPage">
            </el-pagination>
        </div>

        <!-- Form -->
        <el-dialog title="权限管理" :visible.sync="dialogFormVisible">
            <el-transfer v-model="value" :data="data" style="text-align: left;"></el-transfer>
             <!-- <tree-transfer :FormData="data" :to_data="value"></tree-transfer> -->
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
            </div>
        </el-dialog>

    </div>
</template>

<script>
// import axios from 'axios';

export default {
    data() {
        const generateData = () => {
            const data = [];
            for (let i = 1; i <= 15; i++) {
                data.push({
                    key: i,
                    label: `备选项 ${i}`,
                    disabled: i % 4 === 0
                });
            }
            return data;
        };
        return {
            tableData: [],
            total: 0,
            pageSize: 5,
            currentPage: 1,
            dialogFormVisible: false,
            formLabelWidth: '120px',
            data: generateData(),
            value: [1, 4],
            selectedRow: {}
        }
    },
    mounted() {
        this.getAdmin();
    },
    methods: {
        getAdmin() {
            this.$axios.post(
                "/admin/getAllAdminByPageByHelper",
                {
                    pagen: this.currentPage,
                    limit: this.pageSize
                }
            ).then((res) => {
                this.tableData = res.data.list
                this.pageSize = res.data.pageSize
                this.total = res.data.total
                console.log(res.data);
            })
        },
        handleCurrentChange(index) {
            this.currentPage = index
            this.getAdmin()
        },
        openForm(row) {
            this.getAdminMenu(row.adminId);
            this.dialogFormVisible = true
            console.log(row);
        },
        getAdminMenu(adminId){
            this.$axios.post(
                "/menu/searchMenuByRoleInTree",
                {
                    roleId:adminId
                }
            ).then((res)=>{
                console.log(res);
                this.selectedRow = res.data
                console.log(this.selectedRow);
            })
        }
    },
    components:{
    }
}

</script>

<style scoped>
.el-table {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 20px;
}

.el-transfer-panel__item .el-checkbox__inputt{
    position: absolute;
    top: 8px;
    left: 20px !important; 
}
</style>