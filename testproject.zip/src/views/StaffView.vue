<template>
    <div>
        <el-table :data="tableData" style="width: 100%">
            <el-table-column prop="adminId" label="id" width="180">
            </el-table-column>
            <el-table-column prop="adminAccount" label="账号" width="180">
            </el-table-column>
            <el-table-column prop="adminPwd" label="密码">
            </el-table-column>
            <el-table-column prop="adminName" label="昵称">
            </el-table-column>
            <el-table-column label="操作">
                <el-button>编辑</el-button>
            </el-table-column>
        </el-table>
        <div class="block">
            <el-pagination layout="prev, pager, next" :total=total :page-size="pageSize"
                @current-change="handleCurrentChange" :current-page="currentPage">
            </el-pagination>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    data() {
        return {
            tableData:[],
            total:0,
            pageSize:3,
            currentPage:1,
        }
    },
    mounted() {
        this.getAdmin();
    },
    methods: {
        getAdmin() {
            axios.post(
                "/api/admin/getAllAdminByPageByHelper",
                {
                    pagen: this.currentPage,
                    limit: this.pageSize
                }
            ).then((res) => {
                this.tableData = res.data.data.list
                this.pageSize = res.data.data.pageSize
                this.total = res.data.data.total
                console.log(res.data.data);
            })
        },
        handleCurrentChange(index){
            this.currentPage = index
            this.getAdmin()
        }
    }
}

</script>

<style scoped>
.el-table {
    background-color: #E9EEF3;
    color: #333;
    text-align: center;
    line-height: 20px;
}
</style>